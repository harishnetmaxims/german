<?php

namespace App\Http\Controllers;

use App\Add_video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AddVideoController extends Controller
{





    public function add_video(Request $request)
    {
        $res =new add_video;
        $res->pedigree=$request->input('pedigree');
        $res->title=$request->input('title');
        $res->description=$request->input('description');
        $res->tags=$request->input('tags');
        $res->cat=$request->input('cat');
        $res->sub_cat=$request->input('sub_cat');
        $res->video = $request->file('file')->store('upload_vid');
        $res->username =$request->session()->get('name');
        $res->save();
        $request->session()->flash('msg','Video Uploaded!!');
        return redirect('manage-videos');
    }

    public function manage_videos(Add_video $add_video)
    {
        $result = DB::table('Add_videos')->where('username',session()->get('name'))->get();
        $data = Add_video::paginate(6);
        return view('manage-videos',compact('result'))->with('todoCat',$data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Add_video  $add_video
     * @return \Illuminate\Http\Response
     */
    public function show(Add_video $add_video)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Add_video  $add_video
     * @return \Illuminate\Http\Response
     */
    public function edit(Add_video $add_video)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Add_video  $add_video
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Add_video $add_video)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Add_video  $add_video
     * @return \Illuminate\Http\Response
     */
    public function destroy(Add_video $add_video)
    {
        //
    }
}
