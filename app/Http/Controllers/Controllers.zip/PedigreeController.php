<?php

namespace App\Http\Controllers;

use App\ManagePedigree;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PedigreeController extends Controller
{
    
    public function manage_pedigree() {
        $ret = DB::table('pd_entries')
             ->orderBy('indexer','DESC')
             ->simplePaginate('10');
        return view('webpanel.manage-pedigree',['ret'=>$ret]);
    }

    public function add_pedigree() {
        $image_galleries = DB::table('pd_entries')
                    ->groupBy('gallery_name')
                    ->get();
        return view('webpanel.add-pedigree',['image_galleries'=>$image_galleries]);
    }
    
    public function store(Request $req) {
        $pedigree = new ManagePedigree;
        $pedigree->gallery_id = $req->input('album_id');
        $iatdetail = DB::table('image_galleries')
                        ->where('gallery_id',$pedigree->gallery_id)
                        ->first();
        $pedigree->gallery_name = $iatdetail->gallery_name;
        $pedigree->description = $iatdetail->gallery_description;
        $pedigree->tags = $iatdetail->gallery_tags;
        if($req->file('image')) {
            $req->validate(['image' => 'image|mimes:jpeg,png,jpg,gif|max:2048']);
            $pedigree->image_id = $req->file('image')->getClientOriginalName();
            $req->file('image')->storeAs('public/addons/albums/images/',$pedigree->image_id);
        }
        $pedigree->save();
        $req->session()->flash('msg','Profile Updated successfully');
        return redirect('webadmin/manage-pedigree');
    }

    public function update_pedigree($blog_id) {
        $viddet = DB::table('pd_entries')
                    ->where('indexer',$blog_id)
                    ->first();
        $resultcc = DB::table('image_galleries')
                    ->groupBy('gallery_name')
                    ->get();
        return view('webpanel.update-image',['viddet'=>$viddet,'resultcc'=>$resultcc]);
    }
    
    public function update(Request $req, $id) {
        $pedigree = ManagePedigree::find($id);
        $pedigree->gallery_id = $req->input('album_id');
        $iatdetail = DB::table('image_galleries')
                        ->where('gallery_id',$pedigree->gallery_id)
                        ->first();
        $pedigree->gallery_name = $iatdetail->gallery_name;
        $pedigree->description = $iatdetail->gallery_description;
        $pedigree->tags = $iatdetail->gallery_tags;
        if($req->file('image')) {
            $req->validate(['image' => 'image|mimes:jpeg,png,jpg,gif|max:2048']);
            $pedigree->image_id = $req->file('image')->getClientOriginalName();
            $req->file('image')->storeAs('public/addons/albums/images/',$pedigree->image_id);
        }//$pedigree->image_id = $image;
        $pedigree->save();
        $req->session()->flash('msg','Page Updated Successfully !!');
        return redirect('webadmin/manage-pedigree');
    }
    
    public function delete_pedigree(Request $req,$id,$reg_id) {
        DB::table('pd_koer')
            ->where('sz',$reg_id)
            ->delete();
        DB::table('pd_kork')
            ->where('pd',$reg_id)
            ->delete();
        DB::table('pd_show')
            ->where('sz',$reg_id)
            ->delete();
        DB::table('dp_rabies')
            ->where('pd',$reg_id)
            ->delete();
        DB::table('dp_litters')
            ->where('pd',$reg_id)
            ->delete();
        DB::table('dp_health_matters')
            ->where('pd',$reg_id)
            ->delete();
        DB::table('dp_deworming')
            ->where('pd',$reg_id)
            ->delete();    
        DB::table('dp_vaccines')
            ->where('pd',$reg_id)
            ->delete();
        DB::table('pd_entries')
            ->where('indexer',$id)
            ->delete();
        $req->session()->flash('msg','Pedigree deleted');
        return redirect('webadmin/manage-pedigree');
    }

    public function pedi(Request $req) {
        $search = $req->input('search');
        echo '
        <div class="row">
            <div class="relates">
                <div class="relatessec">
                    <ul class="serchfor">';
                    $mem = DB::table('pd_entries')
                                    ->where('name', 'like', '%' . $search .'%')
                                    ->orwhere('lastname', 'like', '%' . $search .'%')
                                    ->orwhere('reg1', 'like', '%' . $search .'%')
                                    ->limit(10);
                    $memresult = $mem->get();
                    $memcount = $mem->count(); 
                    if ($memcount > 0) {
                        foreach($memresult as $memrow) {
                
                        echo '<li><a href="update-pedigree/'.$memrow->reg1.'">'.utf8_decode($memrow->name) .utf8_decode($memrow->lastname).'('.$memrow->reg1.')</a></li>';
                  
                        } 
                    } else { 
                        
                    } 
                    echo '</ul> 
                </div>
            </div>
        </div>';
    }


}
